package com.mohamed.cloner;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        // تسجيل الجسر البرمجي للربط بين الزرار والسيستم
        this.getBridge().getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void startWorkProfile() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        provisionManagedProfile();
                    }
                });
            }
        }, "AndroidBridge");
    }

    private void provisionManagedProfile() {
        Intent intent = new Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE);
        ComponentName admin = new ComponentName(this, MyDeviceAdminReceiver.class);
        intent.putExtra(DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME, admin);
        
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, 555);
        } else {
            // رسالة احتياطية لو الجهاز مش بيدعم
            android.widget.Toast.makeText(this, "عذراً، هذا الجهاز قد لا يدعم ملفات العمل", android.widget.Toast.LENGTH_LONG).show();
        }
    }
}