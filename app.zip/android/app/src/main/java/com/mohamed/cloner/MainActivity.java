package com.mohamed.cloner;

import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import com.getcapacitor.BridgeActivity;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.List;

public class MainActivity extends BridgeActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        this.getBridge().getWebView().addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void getInstalledApps() {
                runOnUiThread(() -> {
                    JSONArray appsArray = new JSONArray();
                    PackageManager pm = getPackageManager();
                    List<ApplicationInfo> apps = pm.getInstalledApplications(PackageManager.GET_META_DATA);
                    
                    try {
                        for (ApplicationInfo app : apps) {
                            // تصفية تطبيقات النظام لو حبيت، بس هنا هنعرض كله
                            JSONObject obj = new JSONObject();
                            obj.put("name", app.loadLabel(pm).toString());
                            obj.put("package", app.packageName);
                            appsArray.put(obj);
                        }
                        String json = appsArray.toString();
                        getBridge().getWebView().evaluateJavascript("displayApps('" + json.replace("'", "\\'") + "')", null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }

            @JavascriptInterface
            public void cloneApp(String packageName) {
                runOnUiThread(() -> {
                    try {
                        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
                        ComponentName admin = new ComponentName(MainActivity.this, MyDeviceAdminReceiver.class);
                        
                        if (dpm.isProfileOwnerApp(packageName)) {
                             // البروفايل موجود فعلاً
                        }
                        
                        // أمر النسخ الذكي لبروفايل العمل
                        dpm.enableSystemApp(admin, packageName);
                        // أو محاولة التثبيت لو تطبيق مش نظام
                        Intent intent = new Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE);
                        // لاحظ: النسخ المباشر بيحتاج صلاحيات Root أو Device Owner كامل
                        // هنا بنفتح الإعدادات لتسهيل العملية للمستخدم حالياً
                        android.widget.Toast.makeText(MainActivity.this, "تم طلب نسخة لـ " + packageName, android.widget.Toast.LENGTH_SHORT).show();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                });
            }
        }, "AndroidBridge");
    }
}