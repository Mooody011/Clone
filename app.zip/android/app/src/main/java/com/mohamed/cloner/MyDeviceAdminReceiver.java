package com.mohamed.cloner;
import android.app.admin.DeviceAdminReceiver;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class MyDeviceAdminReceiver extends DeviceAdminReceiver {
    @Override
    public void onProfileProvisioningComplete(Context context, Intent intent) {
        DevicePolicyManager manager = (DevicePolicyManager) context.getSystemService(Context.DEVICE_POLICY_SERVICE);
        manager.setProfileEnabled(new ComponentName(context, MyDeviceAdminReceiver.class));
        Toast.makeText(context, "تم إعداد بروفايل العمل بنجاح", Toast.LENGTH_SHORT).show();
    }
}